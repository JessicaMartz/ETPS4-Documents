/*
crear una clase que permita crear cuentas bancarias. la clse ha de tener s siguientes requisitos:
nombre: ParciaII
tendra las sigiente propiedades:
    saldoDeCuenta
    nombreDelTitular
    numeroDeCuenta
constructor de la clase con parametros 
    nombreDelTitular
    saldoDeCuenta
Metdos de la clase:
    se crearan 2 setters, uno para hacer ingresos (setIngreso) y otro para hacer reintegros (setReintegro). se creara en un objeto de tipo Parcial.
    se creara 2 getters, uno permitira obtener el saldo (getSaldoCuenta) de la cuenta corriente y el otro obtendra los dats generales (getDatosCuenta) de una Parcial.
    se creara un metodo (RealizarTransferenciaEntreCuentas) para permitir realizar transferencias ed dinero de una cuenta a otra.

el constructor de la clase Parcia sera el encargad de establecer:
  un nombre para el titular de a cuenta criente
  un sldo nicial ara la cuenta corriente
  Asignara un numero de cuenta corriente, de tp ln, de frma aleatoria
La clase arcia se creara en una case rincipa lamada OperacionesBanco. En esta clase rincipal OperacinesBanc se crearan dos instancias de la clase Parcial, con el nombre Parcia_1 y Parcial_2
para probar la correcta creacion de os metodos de Parcial, se realizara una transferencia desde la Parcial_1 a la Parcial_2. se mostrara todos los datos de ambas cuentas Parcia_1 y Parcial_2 para comprobar
*/

import Foundation

class Parcial {
    var saldoDeCuenta: Double
    var nombreDelTitular: String
    var numeroDeCuenta: String

    init(nombreDelTitular: String, saldoDeCuenta: Double) {
        self.nombreDelTitular = nombreDelTitular
        self.saldoDeCuenta = saldoDeCuenta
        self.numeroDeCuenta = "" 
        self.numeroDeCuenta = generarNumeroDeCuenta() 
    }

    private func generarNumeroDeCuenta() -> String {
        let numeroAleatorio = Int.random(in: 100000..<999999)
        return "CC\(numeroAleatorio)"
    }

    func setIngreso(monto: Double) {
        saldoDeCuenta += monto
    }

    func setReintegro(monto: Double) {
        if monto > saldoDeCuenta {
            print("No hay saldo suficiente para el reintegro.")
        } else {
            saldoDeCuenta -= monto
        }
    }

    func getSaldoCuenta() -> Double {
        return saldoDeCuenta
    }

    func getDatosCuenta() -> String {
        return "Titular: \(nombreDelTitular), Número de cuenta: \(numeroDeCuenta), Saldo: \(saldoDeCuenta)"
    }

    func realizarTransferenciaEntreCuentas(otraCuenta: Parcial, monto: Double) {
        if monto > saldoDeCuenta {
            print("No hay saldo suficiente para realizar la transferencia.")
        } else {
            saldoDeCuenta -= monto
            otraCuenta.setIngreso(monto: monto)
            print("Transferencia exitosa.")
        }
    }
}

class OperacionesBanco {
    var parcial1: Parcial
    var parcial2: Parcial

    init() {
        parcial1 = Parcial(nombreDelTitular: "Parcial_1", saldoDeCuenta: 1000.0)
        parcial2 = Parcial(nombreDelTitular: "Parcial_2", saldoDeCuenta: 500.0)

        // Realizar una transferencia de parcial1 a parcial2
        parcial1.realizarTransferenciaEntreCuentas(otraCuenta: parcial2, monto: 200.0)

        // Mostrar los datos de ambas cuentas
        print("Datos de Parcial_1:")
        print(parcial1.getDatosCuenta())
        print("")

        print("Datos de Parcial_2:")
        print(parcial2.getDatosCuenta())
    }
}

// Ejemplo de uso
let operacionesBanco = OperacionesBanco()


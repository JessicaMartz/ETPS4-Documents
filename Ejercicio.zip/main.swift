var valorA = 3;
var valorB = 4;
var result: Int;
var result1: Int;
var result2: Int;

result  = valorA+valorB;
result1  = valorA-valorB;
result2  = valorA*valorB;

if result>valorA{
  print("EL VALOR DE A ES: \(valorA) \n \nEl resultado de la suma es: \(result)\nEl resultado de la resta es: \(result1)\nEl resultado de la mul es: \(result2)\n")
  print("el numero \(result) es mayor que \(valorA)")
  if result1>valorA{
    print("el numero \(result1) es mayor que \(valorA)")
  }else{
    print("el numero \(result1) es menor que \(valorA)")
  }
  if result2>valorA{
    print("el numero \(result2) es mayor que \(valorA)")
  }else{
     print("el numero \(result2) es menor que \(valorA)")
  }
}else {
  print("el numero  \(result) es menor que \(valorA)")
}
